
package com.cg.wallet.dao;

import java.util.HashMap;
import java.util.Optional;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	String printran=null;
	static HashMap<Integer,Customer> custmap=new HashMap<Integer,Customer>();
	static HashMap<Integer,Wallet> walletmap=new HashMap<Integer,Wallet>();
	
	@Override
	public int createAccount(Customer customer) throws WalletException {

	try {
			if(custmap.size()==0)
			{
				customer.setId(1001);
			}
			else {
				Optional<Integer> id=custmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int custid=id.get()+1;
				customer.setId(custid);
			}
			custmap.put(customer.getId(), customer);
			return customer.getId();
			
		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public int assignAccount(String type) throws WalletException {
		Wallet wallet=new Wallet();
		double balanceAmount=0;
		try {
			if(walletmap.size()==0)
			{
				wallet.setAccountno(5001);
				wallet.setBalance(balanceAmount);
			}
			else {
				Optional <Integer> account=walletmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accno=account.get()+1;
				wallet.setAccountno(accno);
				wallet.setBalance(balanceAmount);
			}
			
			walletmap.put(wallet.getAccountno(), wallet);

		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
		return wallet.getAccountno();
	}

	@Override
	public double showBalance(int accno) throws WalletException {

		Wallet value=new Wallet();
		double balance=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					balance= value.getBalance();
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return balance;
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {

		Wallet value=new Wallet();
		double famount=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()+amount;
					value.setBalance(famount);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return famount;
	}

	@Override
	public double withdraw(int accno, double amount) throws WalletException {
		Wallet value=new Wallet();
		double famount=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()-amount;
					value.setBalance(famount);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return famount;
	}

	@Override
	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {
		
		Wallet value1=new Wallet();	
		Wallet value2=new Wallet();

		
		double fromfinalamount=0;
		double tofinalamount=0;
		int status=0;
	
		try {
			if(!walletmap.containsKey(faccno)&&!walletmap.containsKey(taccno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value1=walletmap.get(faccno);
					value2=walletmap.get(taccno);

					fromfinalamount=(value1.getBalance()-amount);
					value1.setBalance(fromfinalamount);
					tofinalamount=(int) (value2.getBalance()+amount);
					value2.setBalance(tofinalamount);
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	
	}
	
	
}

