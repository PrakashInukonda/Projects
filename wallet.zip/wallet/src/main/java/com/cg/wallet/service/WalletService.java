
package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.WalletException;

public interface WalletService {
boolean validateWallet(Customer customer) throws WalletException;
public int createAccount(Customer customer) throws WalletException;
public double showBalance(int accno) throws WalletException;
public double deposit(int accno,double amount) throws WalletException;
public double withdraw(int accno,double amount) throws WalletException;
public int fundTransfer(int faccno,int taccno,double amount) throws WalletException;
}